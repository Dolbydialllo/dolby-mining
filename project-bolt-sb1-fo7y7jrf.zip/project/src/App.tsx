import React from 'react';
import {
  BarChart3,
  Truck,
  Timer,
  Shovel,
  Wrench,
  Activity,
  TrendingUp,
  AlertTriangle,
  Calendar,
} from 'lucide-react';

function KPICard({ title, value, icon: Icon, trend, unit = '' }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <h3 className="text-gray-600 font-medium">{title}</h3>
        </div>
        {trend && (
          <span className={`flex items-center ${trend > 0 ? 'text-green-500' : 'text-red-500'}`}>
            <TrendingUp className={`w-4 h-4 ${trend < 0 ? 'rotate-180' : ''} mr-1`} />
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <p className="text-3xl font-bold text-gray-800">
        {value}
        <span className="text-lg text-gray-500 ml-1">{unit}</span>
      </p>
    </div>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-600 text-white p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">Mining Operations Dashboard</h1>
          <p className="mt-2 text-blue-100">Production & Maintenance KPIs</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-8 px-4">
        {/* Production Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Production Metrics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <KPICard
              title="Daily Production"
              value="45,280"
              unit="tonnes"
              icon={Truck}
              trend={5.2}
            />
            <KPICard
              title="Stripping Ratio"
              value="3.8"
              unit=":1"
              icon={Shovel}
              trend={-2.1}
            />
            <KPICard
              title="Operating Hours"
              value="22.5"
              unit="hrs"
              icon={Timer}
              trend={1.8}
            />
          </div>
        </section>

        {/* Maintenance Section */}
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Maintenance Performance</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <KPICard
              title="Equipment Availability"
              value="92.4"
              unit="%"
              icon={Activity}
              trend={3.1}
            />
            <KPICard
              title="MTBF"
              value="168"
              unit="hrs"
              icon={Wrench}
              trend={7.5}
            />
            <KPICard
              title="Unplanned Downtime"
              value="4.2"
              unit="%"
              icon={AlertTriangle}
              trend={-12.3}
            />
          </div>
        </section>

        {/* Weekly Performance Chart */}
        <section className="mt-12">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Weekly Production Trend</h3>
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-gray-500" />
                <span className="text-gray-600">Last 7 Days</span>
              </div>
            </div>
            <div className="h-64 flex items-end justify-between space-x-2">
              {[65, 72, 86, 81, 74, 78, 90].map((value, index) => (
                <div key={index} className="relative flex-1">
                  <div
                    className="bg-blue-500 rounded-t-sm hover:bg-blue-600 transition-colors"
                    style={{ height: `${value}%` }}
                  ></div>
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-4 text-sm text-gray-600">
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
              <span>Sun</span>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;